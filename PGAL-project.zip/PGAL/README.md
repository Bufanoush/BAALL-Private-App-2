# Private gallery (silver)
Android app: private photos and videos in a hidden folder. Package com.pgal.app.
Build: upload this zip to a GitHub repo together with .github/workflows/build.yml, then take app-release.apk from Releases.
