package com.pgal.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class LockSetupActivity : BaseActivity() {
    private lateinit var dir: File
    private lateinit var meta: FolderMeta
    private var type = 0 // 0 pattern, 1 pin, 2 password
    private lateinit var area: LinearLayout
    private lateinit var optBox: LinearLayout
    private lateinit var fpSwitch: Switch
    private var firstPattern: String? = null
    private var confirmedPattern: String? = null
    private var patLabel: TextView? = null
    private var f1: EditText? = null
    private var f2: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dir = File(Vault.root(), intent.getStringExtra("name") ?: "")
        meta = Vault.readMeta(dir)
        type = when (meta.lock) { "pin" -> 1; "password" -> 2; else -> 0 }
        val root = vbox().apply { setBackgroundColor(Color.BLACK) }
        val (bar, _) = topBar("قفل فولدر \"${dir.name}\"") { finish() }
        root.addView(bar); root.addView(divider(), lp(h = 1))
        val b = vbox().apply { setPadding(dp(16), dp(16), dp(16), dp(20)) }
        optBox = vbox()
        b.addView(optBox)
        area = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
        b.addView(area, lp(t = 10, b = 10))
        val fc = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fc.addView(label("فتح الفولدر بالبصمة كمان", 14f), LinearLayout.LayoutParams(0, -2, 1f))
        fpSwitch = Switch(this).apply { isChecked = meta.fp }
        fpSwitch.setOnCheckedChangeListener { _, on ->
            if (on && !biometricAvailable()) { fpSwitch.isChecked = false; Toast.makeText(this, "البصمة مش متاحة أو مش متسجلة على الموبايل", Toast.LENGTH_LONG).show() }
        }
        fc.addView(fpSwitch)
        b.addView(fc, lp(b = 14))
        b.addView(button("حفظ القفل") { save() }, lp())
        if (meta.lock != "none") b.addView(button("إزالة القفل", filled = false) { removeLock() }, lp(t = 10))
        root.addView(ScrollView(this).apply { addView(b) }, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        renderOptions(); renderArea()
    }

    private fun renderOptions() {
        optBox.removeAllViews()
        val items = arrayOf(Triple("نمط", "ارسم شكل على ٩ نقط", 0), Triple("PIN", "أرقام من ٤ لـ ٨", 1), Triple("باسورد", "حروف وأرقام ورموز", 2))
        for ((t, s, i) in items) {
            val c = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            if (i == type) (c.background as android.graphics.drawable.GradientDrawable).setStroke(dp(1), ACC)
            val dot = View(this).apply {
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(if (i == type) ACC else Color.TRANSPARENT); setStroke(dp(2), ACC)
                }
            }
            c.addView(dot, lp(w = dp(20), h = dp(20), r = 12))
            val tx = vbox(); tx.addView(label(t, 15f)); tx.addView(label(s, 11f, GREY))
            c.addView(tx)
            c.setOnClickListener { type = i; firstPattern = null; confirmedPattern = null; renderOptions(); renderArea() }
            optBox.addView(c, lp(b = 10))
        }
    }

    private fun renderArea() {
        area.removeAllViews(); f1 = null; f2 = null; patLabel = null
        if (type == 0) {
            val pv = PatternView(this)
            val lab = label("ارسم النمط (٤ نقط على الأقل)", 12f, GREY).apply { gravity = Gravity.CENTER }
            patLabel = lab
            pv.onDone = { seq ->
                val n = seq.split("-").size
                if (n < 4) { lab.text = "٤ نقط على الأقل، جرب تاني"; pv.reset() }
                else if (firstPattern == null) { firstPattern = seq; lab.text = "ارسم النمط تاني للتأكيد"; pv.reset() }
                else if (firstPattern == seq) { confirmedPattern = seq; lab.text = "تم تأكيد النمط. دوس حفظ." }
                else { firstPattern = null; confirmedPattern = null; lab.text = "النمطين مش متطابقين. ارسم من الأول"; pv.reset() }
            }
            area.addView(pv, LinearLayout.LayoutParams(-1, -2))
            area.addView(lab, lp(t = 6))
        } else {
            f1 = pass(if (type == 1) "PIN" else "كلمة السر", numeric = type == 1)
            f2 = pass(if (type == 1) "أكد الـ PIN" else "أكد كلمة السر", numeric = type == 1)
            area.addView(f1, lp(b = 8)); area.addView(f2, lp())
        }
    }

    private fun save() {
        val secret: String
        if (type == 0) {
            secret = confirmedPattern ?: run { Toast.makeText(this, "ارسم النمط وأكده الأول", Toast.LENGTH_LONG).show(); return }
        } else {
            val a = f1!!.text.toString()
            val min = if (type == 1) 4 else 4
            if (a.length < min) { Toast.makeText(this, "لازم $min على الأقل", Toast.LENGTH_LONG).show(); return }
            if (type == 1 && a.length > 8) { Toast.makeText(this, "الـ PIN لحد ٨ أرقام", Toast.LENGTH_LONG).show(); return }
            if (a != f2!!.text.toString()) { Toast.makeText(this, "مش متطابقين", Toast.LENGTH_LONG).show(); return }
            secret = a
        }
        meta.lock = when (type) { 0 -> "pattern"; 1 -> "pin"; else -> "password" }
        meta.secret = Hash.make(secret)
        meta.fp = fpSwitch.isChecked
        Vault.writeMeta(dir, meta)
        Session.openFolders.add(dir.name)
        Toast.makeText(this, "تم حفظ القفل", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun removeLock() {
        dlg(this).setTitle("إزالة القفل؟").setPositiveButton("إزالة") { _, _ ->
            meta.lock = "none"; meta.secret = ""; meta.fp = false
            Vault.writeMeta(dir, meta); finish()
        }.setNegativeButton("إلغاء", null).show()
    }
}
