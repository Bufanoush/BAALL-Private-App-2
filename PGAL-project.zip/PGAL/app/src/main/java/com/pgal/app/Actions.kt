package com.pgal.app

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Actions {
    fun move(a: AppCompatActivity, files: List<File>, done: () -> Unit) {
        val here = files.firstOrNull()?.parentFile
        val targets = Vault.folders().filter { it.dir != here }
        if (targets.isEmpty()) { Toast.makeText(a, "مفيش فولدر تاني. اعمل فولدر جديد الأول.", Toast.LENGTH_LONG).show(); return }
        dlg(a).setTitle("نقل إلى").setItems(targets.map { it.name }.toTypedArray()) { _, w ->
            val dest = targets[w].dir
            Thread {
                var ok = 0
                for (f in files) if (Vault.moveFile(f, dest) != null) ok++
                a.runOnUiThread {
                    Toast.makeText(a, if (ok == files.size) "تم نقل $ok" else "تم نقل $ok من ${files.size}", Toast.LENGTH_LONG).show()
                    done()
                }
            }.start()
        }.setNegativeButton("إلغاء", null).show()
    }

    /** Takes the files out of the private folder and puts them back in the phone's normal Pictures / Movies. */
    fun export(a: AppCompatActivity, files: List<File>, done: () -> Unit) {
        dlg(a).setTitle("إخراج من المعرض الخاص؟")
            .setMessage("الملفات (${files.size}) هتتنقل لفولدر Pictures أو Movies على الموبايل وهتظهر في المعرض العادي، وهتتشال من هنا.")
            .setPositiveButton("إخراج") { _, _ ->
                Thread {
                    var ok = 0
                    val out = ArrayList<String>()
                    for (f in files) {
                        val base = if (Vault.isVideo(f)) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                        val dest = File(Environment.getExternalStoragePublicDirectory(base), "Exported")
                        Vault.moveFile(f, dest)?.let { ok++; out.add(it.path) }
                    }
                    if (out.isNotEmpty()) MediaScannerConnection.scanFile(a, out.toTypedArray(), null, null)
                    a.runOnUiThread {
                        Toast.makeText(a, if (ok == files.size) "تم إخراج $ok" else "تم إخراج $ok من ${files.size}", Toast.LENGTH_LONG).show()
                        done()
                    }
                }.start()
            }.setNegativeButton("إلغاء", null).show()
    }

    fun delete(a: AppCompatActivity, files: List<File>, done: () -> Unit) {
        dlg(a).setTitle("حذف ${files.size} نهائيًا؟")
            .setMessage("مش هتقدر ترجعهم.")
            .setPositiveButton("حذف") { _, _ ->
                Thread {
                    for (f in files) f.delete()
                    a.runOnUiThread { done() }
                }.start()
            }.setNegativeButton("إلغاء", null).show()
    }

    fun details(ctx: Context, f: File) {
        var extra = ""
        if (Vault.isImage(f)) {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(f.path, o)
            if (o.outWidth > 0) extra = "\nالأبعاد: ${o.outWidth}×${o.outHeight}"
        } else if (Vault.isVideo(f)) {
            val r = android.media.MediaMetadataRetriever()
            try {
                r.setDataSource(f.path)
                val w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                if (w != null && h != null) extra += "\nالأبعاد: ${w}×${h}"
                if (d != null) extra += "\nالمدة: ${d / 60000}:${"%02d".format(d / 1000 % 60)}"
            } catch (e: Exception) { } finally { try { r.release() } catch (e: Exception) { } }
        }
        val date = SimpleDateFormat("d MMM yyyy، h:mm a", Locale("ar")).format(Date(f.lastModified()))
        dlg(ctx).setTitle("تفاصيل").setMessage("الاسم: ${f.name}\nالحجم: ${Vault.fmtSize(f.length())}$extra\nالتاريخ: $date\nالملف الأصلي من غير أي ضغط.")
            .setPositiveButton("تمام", null).show()
    }
}
