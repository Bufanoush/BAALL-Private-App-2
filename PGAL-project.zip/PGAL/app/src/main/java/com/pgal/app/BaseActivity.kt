package com.pgal.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

open class BaseActivity : AppCompatActivity() {
    protected open val needsUnlock = true

    override fun onCreate(savedInstanceState: Bundle?) {
        // Hides content from screenshots, screen recording and the recent-apps preview.
        if (Prefs.secure) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        super.onCreate(savedInstanceState)
    }

    override fun onStart() {
        super.onStart()
        Session.suppress = false
        if (needsUnlock && !Session.unlocked) startActivity(Intent(this, LockActivity::class.java))
    }

    fun biometricAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    fun askFingerprint(title: String, onOk: () -> Unit) {
        if (!biometricAvailable()) return
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("إلغاء")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        p.authenticate(info)
    }
}
