package com.pgal.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts

class ImportActivity : BaseActivity() {
    private var folders: List<Folder> = emptyList()
    private var target: String? = null
    private var uris: List<Uri> = emptyList()
    private lateinit var folderLabel: TextView
    private lateinit var pickLabel: TextView
    private lateinit var progLabel: TextView
    private lateinit var prog: ProgressBar
    private lateinit var progCard: LinearLayout
    private lateinit var del: Switch
    private lateinit var go: TextView
    private var busy = false

    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) { uris = list; pickLabel.text = "تم اختيار ${list.size} ملف"; }
    }
    private val deleteReq = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        Toast.makeText(this, if (r.resultCode == RESULT_OK) "تم مسح الأصول من المعرض" else "الأصول فضلت زي ما هي", Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        target = intent.getStringExtra("name")
        val root = vbox().apply { setBackgroundColor(Color.BLACK) }
        val (bar, _) = topBar("إضافة للمعرض") { finish() }
        root.addView(bar); root.addView(divider(), lp(h = 1))
        val b = vbox().apply { setPadding(dp(18), dp(18), dp(18), dp(18)) }
        folderLabel = label("", 14f, ACC_L).apply { setOnClickListener { chooseFolder() } }
        b.addView(label("الإضافة لفولدر:", 14f, 0xFFAAAAAA.toInt()), lp(b = 4))
        b.addView(folderLabel, lp(b = 14))
        val pc = card().apply { gravity = Gravity.CENTER; setPadding(dp(12), dp(26), dp(12), dp(26)) }
        pc.addView(label("🖼", 34f).apply { gravity = Gravity.CENTER })
        pc.addView(label("اختار صور وفيديوهات", 16f, ACC_L).apply { gravity = Gravity.CENTER }, lp(t = 8, b = 4))
        pickLabel = label("من معرض الموبايل أو الملفات", 12f, GREY).apply { gravity = Gravity.CENTER }
        pc.addView(pickLabel)
        pc.setOnClickListener { Session.suppress = true; pick.launch(arrayOf("image/*", "video/*")) }
        b.addView(pc, lp(b = 14))
        progCard = card().apply { visibility = View.GONE }
        progLabel = label("", 14f)
        prog = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { progressTintList = android.content.res.ColorStateList.valueOf(ACC) }
        progCard.addView(progLabel, lp(b = 8)); progCard.addView(prog)
        progCard.addView(label("النقل بيتم من غير ضغط أو تقليل جودة", 11f, GREY), lp(t = 8))
        b.addView(progCard, lp(b = 14))
        val dc = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        dc.addView(label("مسح الأصل من المعرض بعد النقل", 14f), LinearLayout.LayoutParams(0, -2, 1f))
        del = Switch(this)
        dc.addView(del)
        b.addView(dc, lp(b = 18))
        go = button("إضافة") { start() }
        b.addView(go, lp())
        b.addView(label("المسح اختياري، وبيطلب إذن أندرويد في كل مرة", 11f, 0xFF777777.toInt()).apply { gravity = Gravity.CENTER }, lp(t = 12))
        root.addView(ScrollView(this).apply { addView(b) }, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (!Session.unlocked) return
        folders = Vault.folders()
        if (target == null || folders.none { it.name == target }) target = folders.firstOrNull()?.name
        folderLabel.text = (target ?: "مفيش فولدر. اعمل فولدر الأول") + "  ▾"
    }

    private fun chooseFolder() {
        if (folders.isEmpty()) return
        dlg(this).setTitle("اختار الفولدر").setItems(folders.map { it.name }.toTypedArray()) { _, w ->
            target = folders[w].name; folderLabel.text = target + "  ▾"
        }.show()
    }

    private fun start() {
        if (busy) return
        val t = target ?: run { Toast.makeText(this, "اعمل فولدر الأول من الشاشة الرئيسية", Toast.LENGTH_LONG).show(); return }
        if (uris.isEmpty()) { Toast.makeText(this, "اختار ملفات الأول", Toast.LENGTH_SHORT).show(); return }
        busy = true; go.alpha = 0.5f; progCard.visibility = View.VISIBLE
        val list = uris; val dir = java.io.File(Vault.root(), t)
        prog.max = list.size; prog.progress = 0
        val wantDelete = del.isChecked
        Thread {
            val copied = ArrayList<Uri>()
            for ((i, u) in list.withIndex()) {
                val ok = Vault.copyIn(this, u, dir) != null
                if (ok) copied.add(u)
                runOnUiThread { prog.progress = i + 1; progLabel.text = "جاري النقل... ${i + 1} / ${list.size}" }
            }
            runOnUiThread {
                busy = false; go.alpha = 1f
                val msg = if (copied.size == list.size) "تمت إضافة ${copied.size}" else "تمت إضافة ${copied.size} من ${list.size}"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (wantDelete && copied.isNotEmpty()) deleteOriginals(copied) else finish()
            }
        }.start()
    }

    /** Asks Android to delete the originals (Android shows its own confirmation). */
    private fun deleteOriginals(list: List<Uri>) {
        val media = ArrayList<Uri>()
        val rest = ArrayList<Uri>()
        for (u in list) {
            val m = try { if (android.os.Build.VERSION.SDK_INT >= 31) MediaStore.getMediaUri(this, u) else null } catch (e: Exception) { null }
            if (m != null) media.add(m) else rest.add(u)
        }
        for (u in rest) try { android.provider.DocumentsContract.deleteDocument(contentResolver, u) } catch (e: Exception) { }
        if (media.isNotEmpty() && android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                Session.suppress = true
                deleteReq.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(contentResolver, media).intentSender).build())
                return
            } catch (e: Exception) { Session.suppress = false }
        }
        Toast.makeText(this, "الملفات اتضافت، لكن تعذر مسح الأصول من المعرض", Toast.LENGTH_LONG).show()
        finish()
    }
}
