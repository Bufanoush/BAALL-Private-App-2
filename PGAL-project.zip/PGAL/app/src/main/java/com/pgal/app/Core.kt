package com.pgal.app

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.util.LruCache
import android.webkit.MimeTypeMap
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.max

object Session {
    @Volatile var unlocked = false
    @Volatile var suppress = false
    val openFolders = HashSet<String>()
    fun lock() { unlocked = false; openFolders.clear() }
}

class App : Application() {
    private var started = 0
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Thumbs.init(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: android.app.Activity, b: android.os.Bundle?) {}
            override fun onActivityStarted(a: android.app.Activity) { started++ }
            override fun onActivityResumed(a: android.app.Activity) {}
            override fun onActivityPaused(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {
                started--
                if (started <= 0 && !a.isChangingConfigurations && !Session.suppress) Session.lock()
            }
            override fun onActivitySaveInstanceState(a: android.app.Activity, b: android.os.Bundle) {}
            override fun onActivityDestroyed(a: android.app.Activity) {}
        })
    }
}

object Hash {
    private val rnd = SecureRandom()
    fun salt(): ByteArray = ByteArray(16).also { rnd.nextBytes(it) }
    fun kdf(secret: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(secret.toCharArray(), salt, 60000, 256)).encoded
    fun b64(b: ByteArray): String = android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP)
    fun unb64(s: String): ByteArray = android.util.Base64.decode(s, android.util.Base64.NO_WRAP)
    /** Returns "salt:hash" */
    fun make(secret: String): String { val s = salt(); return b64(s) + ":" + b64(kdf(secret, s)) }
    fun check(secret: String, stored: String): Boolean = try {
        val (s, h) = stored.split(":")
        MessageDigest.isEqual(kdf(secret, unb64(s)), unb64(h))
    } catch (e: Exception) { false }
}

object Prefs {
    private lateinit var p: android.content.SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("pgal", Context.MODE_PRIVATE) }
    val hasPassword get() = p.contains("pw")
    fun setPassword(s: String) { p.edit().putString("pw", Hash.make(s)).apply() }
    fun checkPassword(s: String) = Hash.check(s, p.getString("pw", "") ?: "")
    var fingerprint: Boolean get() = p.getBoolean("fp", false); set(v) { p.edit().putBoolean("fp", v).apply() }
    var secure: Boolean get() = p.getBoolean("secure", true); set(v) { p.edit().putBoolean("secure", v).apply() }
    val question: String get() = p.getString("q", "") ?: ""
    fun setQuestion(q: String, a: String) { p.edit().putString("q", q).putString("a", Hash.make(a.trim().lowercase())).apply() }
    fun clearQuestion() { p.edit().remove("q").remove("a").apply() }
    fun checkAnswer(a: String) = Hash.check(a.trim().lowercase(), p.getString("a", "") ?: "")
}

class FolderMeta(var lock: String = "none", var secret: String = "", var fp: Boolean = false, var cover: Boolean = false) {
    fun toJson() = JSONObject().put("lock", lock).put("secret", secret).put("fp", fp).put("cover", cover)
    companion object {
        fun from(j: JSONObject) = FolderMeta(j.optString("lock", "none"), j.optString("secret", ""), j.optBoolean("fp", false), j.optBoolean("cover", false))
    }
}

class Folder(val dir: File, val meta: FolderMeta, val count: Int, val videos: Int) {
    val name: String get() = dir.name
    val locked: Boolean get() = meta.lock != "none"
}

object Vault {
    const val ROOT_NAME = ".PrivateGallery"
    private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif", "dng")
    private val VID = setOf("mp4", "mkv", "mov", "avi", "webm", "3gp", "m4v", "ts", "flv", "wmv", "mpg", "mpeg")

    fun root(): File = File(Environment.getExternalStorageDirectory(), ROOT_NAME)

    fun hasAccess(): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else true

    /** Creates the hidden root and the .nomedia file so the phone gallery skips it. */
    fun init(): Boolean = try {
        val r = root(); r.mkdirs()
        val nm = File(r, ".nomedia"); if (!nm.exists()) nm.createNewFile()
        r.isDirectory
    } catch (e: Exception) { false }

    fun ext(f: File) = f.extension.lowercase()
    fun isVideo(f: File) = ext(f) in VID
    fun isImage(f: File) = ext(f) in IMG
    fun isMedia(f: File) = f.isFile && !f.name.startsWith(".") && (isImage(f) || isVideo(f))
    fun mime(f: File): String = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(f)) ?: if (isVideo(f)) "video/*" else "image/*"

    fun items(dir: File): List<File> = (dir.listFiles() ?: emptyArray()).filter { isMedia(it) }.sortedByDescending { it.lastModified() }

    fun metaFile(dir: File) = File(dir, ".f.json")
    fun readMeta(dir: File): FolderMeta = try { FolderMeta.from(JSONObject(metaFile(dir).readText())) } catch (e: Exception) { FolderMeta() }
    fun writeMeta(dir: File, m: FolderMeta) { try { metaFile(dir).writeText(m.toJson().toString()) } catch (e: Exception) { } }
    fun coverFile(dir: File) = File(dir, ".cover.jpg")

    fun folders(): List<Folder> {
        val dirs = root().listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") } ?: return emptyList()
        return dirs.map { d ->
            val it = items(d)
            Folder(d, readMeta(d), it.size, it.count { f -> isVideo(f) })
        }.sortedByDescending { f -> f.dir.lastModified() }
    }

    fun createFolder(name: String): Folder? {
        val n = name.trim().replace(Regex("[/\\\\:*?\"<>|]"), "_").trimStart('.')
        if (n.isEmpty()) return null
        val d = File(root(), n)
        if (d.exists()) return null
        if (!d.mkdirs()) return null
        return Folder(d, FolderMeta(), 0, 0)
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name); val ex = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) { f = File(dir, if (ex.isEmpty()) "$base ($i)" else "$base ($i).$ex"); i++ }
        return f
    }

    fun copyIn(ctx: Context, uri: android.net.Uri, dir: File, onBytes: (Long) -> Unit = {}): File? {
        val name = ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "file_" + System.currentTimeMillis()
        val out = uniqueFile(dir, name.replace('/', '_'))
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { o -> copy(i, o, onBytes) } }
        } catch (e: Exception) { out.delete(); return null }
        return out
    }

    private fun copy(i: InputStream, o: java.io.OutputStream, onBytes: (Long) -> Unit) {
        val buf = ByteArray(256 * 1024)
        while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); onBytes(n.toLong()) }
    }

    /** Moves a file; falls back to copy + delete across volumes. Returns the new file or null. */
    fun moveFile(f: File, destDir: File): File? {
        destDir.mkdirs()
        val t = uniqueFile(destDir, f.name)
        if (f.renameTo(t)) return t
        return try { f.inputStream().use { i -> t.outputStream().use { o -> copy(i, o) {} } }; t.setLastModified(f.lastModified()); f.delete(); t } catch (e: Exception) { t.delete(); null }
    }

    fun fmtSize(b: Long): String = when {
        b >= 1L shl 30 -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(java.util.Locale.US, "%d KB", b / 1024)
    }
}

object Thumbs {
    private lateinit var dir: File
    private val mem = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 8).toInt()).coerceAtMost(48 * 1024 * 1024)) {
        override fun sizeOf(k: String, v: Bitmap) = v.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    fun init(c: Context) { dir = File(c.cacheDir, "th").apply { mkdirs() } }

    private fun key(f: File, size: Int): String {
        val d = MessageDigest.getInstance("MD5").digest("${f.absolutePath}|${f.lastModified()}|${f.length()}|$size".toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    fun peek(f: File, size: Int): Bitmap? = mem.get(key(f, size))

    /** Loads a thumbnail on a worker thread and delivers it on the UI thread. */
    fun load(f: File, size: Int, cb: (Bitmap?) -> Unit) {
        val k = key(f, size)
        mem.get(k)?.let { cb(it); return }
        pool.execute {
            var b: Bitmap? = null
            val df = File(dir, "$k.jpg")
            try {
                if (df.exists()) b = BitmapFactory.decodeFile(df.path)
                if (b == null) {
                    b = make(f, size)
                    if (b != null) df.outputStream().use { b!!.compress(Bitmap.CompressFormat.JPEG, 82, it) }
                }
            } catch (e: Throwable) { }
            if (b != null) mem.put(k, b)
            ui.post { cb(b) }
        }
    }

    fun make(f: File, size: Int): Bitmap? {
        if (Vault.isVideo(f)) {
            val r = MediaMetadataRetriever()
            return try {
                r.setDataSource(f.path)
                val fr = r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0)
                fr?.let { scale(it, size) }
            } catch (e: Throwable) { null } finally { try { r.release() } catch (e: Throwable) { } }
        }
        return decode(f, size)
    }

    fun decode(f: File, maxSide: Int): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { dec, info, _ ->
            val m = max(info.size.width, info.size.height)
            if (m > maxSide) {
                val sc = maxSide.toFloat() / m
                dec.setTargetSize((info.size.width * sc).toInt().coerceAtLeast(1), (info.size.height * sc).toInt().coerceAtLeast(1))
            }
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Throwable) { null }

    private fun scale(b: Bitmap, size: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= size) return b
        val sc = size.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * sc).toInt().coerceAtLeast(1), (b.height * sc).toInt().coerceAtLeast(1), true)
    }

    /** Heavily shrunk copy that looks blurred when stretched (used for locked folders). */
    fun blurred(b: Bitmap): Bitmap = Bitmap.createScaledBitmap(b, 10, (10f * b.height / b.width).toInt().coerceAtLeast(1), true)

    fun jpeg(b: Bitmap, q: Int = 85): ByteArray { val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, q, o); return o.toByteArray() }
}
