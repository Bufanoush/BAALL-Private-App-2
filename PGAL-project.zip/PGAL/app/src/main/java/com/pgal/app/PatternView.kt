package com.pgal.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** 3x3 pattern pad. Calls onDone with a string like "0-3-4-7" when the finger lifts. */
class PatternView(ctx: Context) : View(ctx) {
    var onDone: ((String) -> Unit)? = null
    private val seq = ArrayList<Int>()
    private var fx = 0f; private var fy = 0f; private var drawing = false
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(2).toFloat(); color = 0xFF666666.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(4).toFloat(); color = withAlpha(ACC, 0xAA); strokeCap = Paint.Cap.ROUND }

    private fun cx(i: Int): Float = width * (0.2f + 0.3f * (i % 3))
    private fun cy(i: Int): Float = height * (0.2f + 0.3f * (i / 3))
    private fun r(): Float = min(width, height) * 0.09f

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w).coerceAtMost(context.dp(300))
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        for (k in 0 until seq.size - 1) c.drawLine(cx(seq[k]), cy(seq[k]), cx(seq[k + 1]), cy(seq[k + 1]), line)
        if (drawing && seq.isNotEmpty()) c.drawLine(cx(seq.last()), cy(seq.last()), fx, fy, line)
        for (i in 0 until 9) {
            val on = i in seq
            ring.color = if (on) ACC else 0xFF666666.toInt()
            fill.color = if (on) withAlpha(ACC, 0x66) else 0x00000000
            c.drawCircle(cx(i), cy(i), r(), fill)
            c.drawCircle(cx(i), cy(i), r(), ring)
        }
    }

    fun reset() { seq.clear(); drawing = false; invalidate() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { seq.clear(); drawing = true; parent?.requestDisallowInterceptTouchEvent(true); hit(e) }
            MotionEvent.ACTION_MOVE -> hit(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drawing = false; invalidate()
                if (seq.isNotEmpty()) onDone?.invoke(seq.joinToString("-"))
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun hit(e: MotionEvent) {
        fx = e.x; fy = e.y
        for (i in 0 until 9) if (i !in seq && hypot(e.x - cx(i), e.y - cy(i)) < r() * 1.6f) { seq.add(i); break }
        invalidate()
    }
}
