package com.pgal.app

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.Toast

class SecurityActivity : BaseActivity() {
    private lateinit var fp: Switch
    private lateinit var q: Switch
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox().apply { setBackgroundColor(Color.BLACK) }
        val (bar, _) = topBar("الأمان والخصوصية") { finish() }
        root.addView(bar); root.addView(divider(), lp(h = 1))
        val b = vbox().apply { setPadding(dp(16), dp(16), dp(16), dp(20)) }
        fun row(t: String, s: String, on: Boolean, sw: (Switch) -> Unit): Switch {
            val c = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            val tx = vbox(); tx.addView(label(t, 15f)); tx.addView(label(s, 11f, GREY), lp(t = 3))
            c.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
            val w = Switch(this).apply { isChecked = on }
            sw(w); c.addView(w)
            b.addView(c, lp(b = 12))
            return w
        }
        fp = row("فتح بالبصمة", "وكلمة السر تفضل شغالة كبديل", Prefs.fingerprint) { w ->
            w.setOnCheckedChangeListener { _, on ->
                if (busy) return@setOnCheckedChangeListener
                if (on && !biometricAvailable()) { setQuiet(w, false); Toast.makeText(this, "البصمة مش متاحة أو مش متسجلة على الموبايل", Toast.LENGTH_LONG).show() }
                else if (on) askFingerprint("تأكيد البصمة") { Prefs.fingerprint = true } .also { }
                else Prefs.fingerprint = false
            }
        }
        q = row("سؤال الأمان", "لو نسيت كلمة السر، تجاوب السؤال وتحط كلمة جديدة. مش بيفتح التطبيق بدلها.", Prefs.question.isNotEmpty()) { w ->
            w.setOnCheckedChangeListener { _, on ->
                if (busy) return@setOnCheckedChangeListener
                if (on) questionDialog() else Prefs.clearQuestion()
            }
        }
        row("إخفاء من التطبيقات الأخيرة", "شاشة سودا بدل معاينة التطبيق، ومنع لقطة الشاشة (يتطبق من الشاشة الجاية)", Prefs.secure) { w ->
            w.setOnCheckedChangeListener { _, on -> Prefs.secure = on }
        }
        b.addView(button("تغيير كلمة السر", filled = false) { changePassword() }, lp(b = 12))
        b.addView(label("من غير إشعارات: التطبيق مش بيبعت أي إشعار ولا بيظهر على الشاشة المقفولة.", 12f, 0xFFAAAAAA.toInt()), lp(b = 10))
        val note = card()
        note.addView(label("الملفات في مجلد مخفي (يبدأ بنقطة + nomedia): مش في المعرض، وتفضل حتى لو التطبيق اتمسح. تظهر في مدير الملفات بس مع \"إظهار الملفات المخفية\". الملفات من غير تشفير، وقفل التطبيق والفولدرات بيحمي الدخول من جوه التطبيق بس.", 12f, 0xFFAAAAAA.toInt()))
        b.addView(note)
        root.addView(ScrollView(this).apply { addView(b) }, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun setQuiet(w: Switch, v: Boolean) { busy = true; w.isChecked = v; busy = false }

    private fun questionDialog() {
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0) }
        val qq = field("السؤال"); val aa = field("الإجابة")
        qq.setText(Prefs.question)
        box.addView(qq, lp(b = 8)); box.addView(aa)
        dlg(this).setTitle("سؤال الأمان").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val a = qq.text.toString().trim(); val b = aa.text.toString().trim()
                if (a.isEmpty() || b.isEmpty()) { Toast.makeText(this, "اكتب السؤال والإجابة", Toast.LENGTH_LONG).show(); setQuiet(q, Prefs.question.isNotEmpty()) }
                else Prefs.setQuestion(a, b)
            }
            .setNegativeButton("إلغاء") { _, _ -> setQuiet(q, Prefs.question.isNotEmpty()) }
            .setOnCancelListener { setQuiet(q, Prefs.question.isNotEmpty()) }.show()
    }

    private fun changePassword() {
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0) }
        val o = pass("كلمة السر الحالية"); val n1 = pass("كلمة السر الجديدة"); val n2 = pass("أكد كلمة السر الجديدة")
        box.addView(o, lp(b = 8)); box.addView(n1, lp(b = 8)); box.addView(n2)
        val d = dlg(this).setTitle("تغيير كلمة السر").setView(box)
            .setPositiveButton("تغيير", null).setNegativeButton("إلغاء", null).create()
        d.setOnShowListener {
            d.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = n1.text.toString()
                if (!Prefs.checkPassword(o.text.toString())) { o.setText(""); o.hint = "كلمة السر الحالية غلط"; return@setOnClickListener }
                if (a.length < 4) { Toast.makeText(this, "أقل من 4 حروف", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                if (a != n2.text.toString()) { Toast.makeText(this, "مش متطابقتين", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                Prefs.setPassword(a); d.dismiss(); Toast.makeText(this, "تم تغيير كلمة السر", Toast.LENGTH_LONG).show()
            }
        }
        d.show()
    }
}
