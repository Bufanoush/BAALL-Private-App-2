package com.pgal.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

class ViewerActivity : BaseActivity() {
    private var items: MutableList<File> = ArrayList()
    private var idx = 0
    private lateinit var iv: ImageView
    private lateinit var play: TextView
    private lateinit var name: TextView
    private lateinit var info: TextView
    private lateinit var counter: TextView
    private val loader = Executors.newSingleThreadExecutor()
    private var gen = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = File(intent.getStringExtra("path") ?: ""); val mode = intent.getIntExtra("mode", 0)
        val dir = f.parentFile
        if (dir == null || !f.exists()) { finish(); return }
        val m = Vault.readMeta(dir)
        if (m.lock != "none" && dir.name !in Session.openFolders) { finish(); return }
        val all = Vault.items(dir)
        items = (when (mode) { 1 -> all.filter { Vault.isImage(it) }; 2 -> all.filter { Vault.isVideo(it) }; else -> all }).toMutableList()
        idx = items.indexOfFirst { it.path == f.path }.coerceAtLeast(0)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))
        play = TextView(this).apply {
            text = "▶"; textSize = 36f; setTextColor(ACC_L); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()); setStroke(dp(2), ACC) }
            setOnClickListener { openExternal() }
        }
        root.addView(play, FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER))
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(30), dp(12), dp(14)); layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        }
        top.addView(label("→", 24f, ACC).apply { setPadding(dp(14), dp(6), dp(14), dp(6)); setOnClickListener { finish() } })
        val tb = vbox()
        name = label("", 15f, Color.WHITE).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
        info = label("", 11f, 0xFFBBBBBB.toInt()).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        tb.addView(name); tb.addView(info)
        top.addView(tb, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        counter = label("", 12f, 0xFFCCCCCC.toInt()).apply { gravity = Gravity.CENTER }
        root.addView(counter, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(104) })
        val bar = LinearLayout(this).apply {
            background = GradientDrawable().apply { setColor(0xAA141414.toInt()); setStroke(dp(1), 0x22FFFFFF); cornerRadius = dp(26).toFloat() }
            setPadding(dp(8), dp(12), dp(8), dp(12)); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun act(t: String, f: () -> Unit) = label(t, 13f, ACC_L).apply { gravity = Gravity.CENTER; setOnClickListener { f() } }
        bar.addView(act("↪\nنقل") { Actions.move(this, listOf(cur())) { removeCurrent() } }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(act("⤓\nإخراج") { Actions.export(this, listOf(cur())) { removeCurrent() } }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(act("ⓘ\nتفاصيل") { Actions.details(this, cur()) }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(act("🗑\nحذف") { Actions.delete(this, listOf(cur())) { removeCurrent() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(36), 0, dp(36), dp(28)) })
        setContentView(root)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (a == null || abs(vx) < 800 || abs(vx) < abs(vy)) return false
                // swiping left goes to the next item, swiping right to the previous one
                if (vx < 0) go(idx + 1) else go(idx - 1)
                return true
            }
        })
        iv.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
        show()
    }

    private fun cur() = items[idx]
    private fun go(i: Int) { if (i in items.indices) { idx = i; show() } }

    private fun removeCurrent() {
        items.removeAt(idx)
        if (items.isEmpty()) { finish(); return }
        if (idx >= items.size) idx = items.size - 1
        show()
    }

    private fun show() {
        val f = cur()
        val g = ++gen
        name.text = f.name
        counter.text = "${idx + 1} / ${items.size}"
        val vid = Vault.isVideo(f)
        play.visibility = if (vid) View.VISIBLE else View.GONE
        info.text = Vault.fmtSize(f.length()) + (if (vid) " · الفيديو بيفتح على برنامجك" else " · الأصلية")
        iv.setImageDrawable(null)
        val dm = resources.displayMetrics
        val side = maxOf(dm.widthPixels, dm.heightPixels)
        loader.execute {
            val d: android.graphics.drawable.Drawable? = try {
                if (vid) Thumbs.make(f, 1000)?.let { android.graphics.drawable.BitmapDrawable(resources, it) }
                else android.graphics.ImageDecoder.decodeDrawable(android.graphics.ImageDecoder.createSource(f)) { dec, i, _ ->
                    val m = maxOf(i.size.width, i.size.height)
                    if (m > side) { val sc = side.toFloat() / m; dec.setTargetSize((i.size.width * sc).toInt().coerceAtLeast(1), (i.size.height * sc).toInt().coerceAtLeast(1)) }
                }
            } catch (e: Throwable) { null }
            runOnUiThread {
                if (g != gen || isDestroyed) return@runOnUiThread
                if (d == null) Toast.makeText(this, "تعذر عرض الملف", Toast.LENGTH_SHORT).show()
                iv.setImageDrawable(d)
                if (d is AnimatedImageDrawable) { d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; d.start() }
            }
        }
    }

    /** Opens the original file in the user's own video app. No copy is made. */
    private fun openExternal() {
        val f = cur()
        try {
            val uri = FileProvider.getUriForFile(this, "com.pgal.app.files", f)
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, Vault.mime(f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            Session.suppress = true
            startActivity(Intent.createChooser(i, "فتح باستخدام").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            Session.suppress = false
            Toast.makeText(this, "مفيش برنامج يفتح الفيديو ده", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() { loader.shutdown(); super.onDestroy() }
}
