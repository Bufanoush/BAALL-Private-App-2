package com.pgal.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class FolderUnlockActivity : BaseActivity() {
    private lateinit var dir: File
    private lateinit var meta: FolderMeta
    private lateinit var msg: TextView
    private var fpShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dir = File(Vault.root(), intent.getStringExtra("name") ?: "")
        meta = Vault.readMeta(dir)
        if (meta.lock == "none") { Session.openFolders.add(dir.name); setResult(RESULT_OK); finish(); return }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.35f }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val cover = Vault.coverFile(dir)
        val src: File? = if (meta.cover && cover.exists()) cover else Vault.items(dir).firstOrNull()
        if (src != null) Thumbs.load(src, 300) { b -> if (b != null) bg.setImageBitmap(Thumbs.blurred(b)) }
        val col = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(28), dp(70), dp(28), dp(20)) }
        col.addView(label("🔒", 34f).apply { gravity = Gravity.CENTER })
        col.addView(label(dir.name, 22f, ACC_L, true).apply { gravity = Gravity.CENTER }, lp(t = 6))
        val prompt = when (meta.lock) { "pattern" -> "ارسم النمط لفتح الفولدر"; "pin" -> "اكتب الـ PIN"; else -> "اكتب كلمة سر الفولدر" }
        col.addView(label(prompt, 13f, 0xFFBBBBBB.toInt()).apply { gravity = Gravity.CENTER }, lp(t = 4, b = 24))
        msg = label("", 14f, 0xFFE57373.toInt()).apply { gravity = Gravity.CENTER }
        when (meta.lock) {
            "pattern" -> {
                val pv = PatternView(this)
                pv.onDone = { seq ->
                    if (Hash.check(seq, meta.secret)) success() else { msg.text = "النمط غلط"; pv.reset() }
                }
                col.addView(pv, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
            }
            else -> {
                val e: EditText = pass(if (meta.lock == "pin") "PIN" else "كلمة السر", numeric = meta.lock == "pin")
                col.addView(e, lp(b = 10))
                col.addView(button("فتح") { check(e) }, lp())
                e.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
                e.setOnEditorActionListener { _, _, _ -> check(e); true }
            }
        }
        col.addView(msg, lp(t = 10))
        if (meta.fp && biometricAvailable()) {
            col.addView(label("☝", 36f, ACC).apply {
                gravity = Gravity.CENTER
                background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(1), ACC) }
                setOnClickListener { tryFp() }
            }, LinearLayout.LayoutParams(dp(68), dp(68)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(20) })
            col.addView(label("أو افتح بالبصمة", 13f, 0xFFBBBBBB.toInt()).apply { gravity = Gravity.CENTER }, lp(t = 6))
        }
        col.addView(label("استخدم باسورد التطبيق بدل ${when (meta.lock) { "pattern" -> "النمط"; "pin" -> "الـ PIN"; else -> "كلمة سر الفولدر" }}", 12f, ACC).apply {
            gravity = Gravity.CENTER; setOnClickListener { appPassword() }
        }, lp(t = 18))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::meta.isInitialized && meta.fp && !fpShown && biometricAvailable() && Session.unlocked) { fpShown = true; tryFp() }
    }

    private fun tryFp() { askFingerprint("افتح الفولدر بالبصمة") { success() } }

    private fun check(e: EditText) {
        if (Hash.check(e.text.toString(), meta.secret)) success() else { msg.text = "غلط"; e.setText("") }
    }

    private fun success() { Session.openFolders.add(dir.name); setResult(RESULT_OK); finish() }

    private fun appPassword() {
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0) }
        val p = pass("كلمة سر التطبيق"); box.addView(p)
        val d = dlg(this).setTitle("باسورد التطبيق").setView(box)
            .setPositiveButton("فتح", null).setNegativeButton("إلغاء", null).create()
        d.setOnShowListener {
            d.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (Prefs.checkPassword(p.text.toString())) { d.dismiss(); success() } else { p.setText(""); p.hint = "كلمة السر غلط" }
            }
        }
        d.show()
    }
}
