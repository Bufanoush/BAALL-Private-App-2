package com.pgal.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

const val ACC = 0xFFC0C4CC.toInt()
const val ACC_L = 0xFFE6E8EC.toInt()
const val CARD = 0xFF0D0D0D.toInt()
const val GREY = 0xFF888888.toInt()

fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

fun dlg(ctx: Context) = androidx.appcompat.app.AlertDialog.Builder(ctx, R.style.Dlg)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.label(text: String, sizeSp: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }

fun Context.field(hint: String): EditText = EditText(this).apply {
    this.hint = hint
    setTextColor(Color.WHITE)
    setHintTextColor(0xFF777777.toInt())
    textSize = 16f
    textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    textAlignment = View.TEXT_ALIGNMENT_TEXT_START
    importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
    inputType = InputType.TYPE_CLASS_TEXT
    imeOptions = imeOptions or 0x1000000
    background = GradientDrawable().apply {
        setColor(Color.BLACK); setStroke(dp(1), withAlpha(ACC, 0x88)); cornerRadius = dp(12).toFloat()
    }
    setPadding(dp(14), dp(12), dp(14), dp(12))
}

private fun Context.eyeIcon(open: Boolean): android.graphics.drawable.Drawable {
    val s = dp(26)
    val bmp = android.graphics.Bitmap.createBitmap(s, s, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = ACC; style = android.graphics.Paint.Style.STROKE; strokeWidth = s / 12f }
    c.drawOval(android.graphics.RectF(s * 0.06f, s * 0.26f, s * 0.94f, s * 0.74f), p)
    p.style = android.graphics.Paint.Style.FILL
    if (open) c.drawCircle(s / 2f, s / 2f, s * 0.12f, p) else { p.style = android.graphics.Paint.Style.STROKE; c.drawLine(s * 0.15f, s * 0.85f, s * 0.85f, s * 0.15f, p) }
    return android.graphics.drawable.BitmapDrawable(resources, bmp).apply { setBounds(0, 0, s, s) }
}

/** Password field with an eye toggle. Plain text input type, so the keyboard keeps its language. */
@android.annotation.SuppressLint("ClickableViewAccessibility")
fun Context.pass(hint: String, numeric: Boolean = false): EditText {
    val e = field(hint)
    e.inputType = (if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT) or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    e.transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
    var shown = false
    e.compoundDrawablePadding = dp(8)
    e.setCompoundDrawablesRelative(null, null, eyeIcon(false), null)
    e.setOnTouchListener { v, ev ->
        if (ev.action == android.view.MotionEvent.ACTION_UP) {
            val rtl = v.layoutDirection == View.LAYOUT_DIRECTION_RTL
            val hit = if (rtl) ev.x <= v.paddingLeft + dp(40) else ev.x >= v.width - v.paddingRight - dp(40)
            if (hit) {
                shown = !shown
                val sel = e.selectionStart
                e.transformationMethod = if (shown) null else android.text.method.PasswordTransformationMethod.getInstance()
                e.setCompoundDrawablesRelative(null, null, eyeIcon(shown), null)
                e.setSelection(sel.coerceAtLeast(0))
                v.performClick()
                return@setOnTouchListener true
            }
        }
        false
    }
    return e
}

fun Context.button(text: String, filled: Boolean = true, onClick: () -> Unit): TextView = TextView(this).apply {
    this.text = text
    textSize = 16f
    gravity = Gravity.CENTER
    typeface = Typeface.DEFAULT_BOLD
    setTextColor(if (filled) Color.BLACK else ACC)
    background = GradientDrawable().apply {
        setColor(if (filled) ACC else Color.TRANSPARENT)
        setStroke(dp(1), ACC); cornerRadius = dp(12).toFloat()
    }
    setPadding(dp(16), dp(14), dp(16), dp(14))
    setOnClickListener { onClick() }
}

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = GradientDrawable().apply {
        setColor(CARD); setStroke(dp(1), withAlpha(ACC, 0x55)); cornerRadius = dp(14).toFloat()
    }
    setPadding(dp(16), dp(14), dp(16), dp(14))
}

fun Context.logo(sizeSp: Float = 26f): TextView = TextView(this).apply {
    text = "PRIVATE"
    textSize = sizeSp
    setTextColor(ACC)
    typeface = Typeface.DEFAULT_BOLD
    letterSpacing = 0.12f
    gravity = Gravity.CENTER
    layoutDirection = View.LAYOUT_DIRECTION_LTR
    background = GradientDrawable().apply { setColor(Color.BLACK); setStroke(dp(2), ACC); cornerRadius = dp(10).toFloat() }
    setPadding(dp(22), dp(8), dp(22), dp(8))
}

fun Context.lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
    LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

fun Context.vbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    layoutDirection = View.LAYOUT_DIRECTION_RTL
}

/** Top bar: back arrow, title, optional right-side actions. */
fun Context.topBar(title: String, onBack: (() -> Unit)?): Pair<LinearLayout, TextView> {
    val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
    if (onBack != null) bar.addView(label("→", 24f, ACC).apply { setPadding(dp(14), dp(6), dp(14), dp(6)); setOnClickListener { onBack() } })
    val t = label(title, 19f, ACC_L, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(8), 0, dp(8), 0) }
    bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
    return Pair(bar, t)
}

fun Context.divider() = View(this).apply { setBackgroundColor(0xFF222222.toInt()) }

fun Context.circleBtn(text: String, onClick: (View) -> Unit) = TextView(this).apply {
    this.text = text; textSize = 18f; setTextColor(ACC); gravity = Gravity.CENTER
    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF161616.toInt()); setStroke(dp(1), 0xFF2A2A2A.toInt()) }
    setOnClickListener { onClick(it) }
}.also { it.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), 0, dp(4), 0) } }
