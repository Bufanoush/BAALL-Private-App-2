package com.pgal.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class FolderSettingsActivity : BaseActivity() {
    private lateinit var dir: File
    private lateinit var meta: FolderMeta
    private lateinit var preview: ImageView
    private lateinit var rv: RecyclerView
    private var items: List<File> = emptyList()
    private var selected: File? = null
    private var phoneBmp: Bitmap? = null
    private var fromPhone = false

    private val pickPhone = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadPhone(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dir = File(Vault.root(), intent.getStringExtra("name") ?: "")
        meta = Vault.readMeta(dir)
        val root = vbox().apply { setBackgroundColor(Color.BLACK) }
        val (bar, _) = topBar("إعدادات فولدر \"${dir.name}\"") { finish() }
        root.addView(bar); root.addView(divider(), lp(h = 1))
        val b = vbox().apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
        b.addView(label("معاينة على كارت الفولدر", 13f, GREY), lp(b = 8))
        val card = FrameLayout(this).apply {
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(20).toFloat()) }
            }
            setBackgroundColor(0xFF161616.toInt())
        }
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        card.addView(preview, FrameLayout.LayoutParams(-1, -1))
        card.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0x00000000)) }, FrameLayout.LayoutParams(-1, -1))
        val tx = vbox().apply { setPadding(dp(14), dp(10), dp(14), dp(10)) }
        tx.addView(label(dir.name, 17f, Color.WHITE, true)); tx.addView(label("${Vault.items(dir).size} عنصر", 11f, ACC_L))
        card.addView(tx, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val w = resources.displayMetrics.widthPixels * 6 / 10
        b.addView(card, LinearLayout.LayoutParams(w, dp(150)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })
        b.addView(label("تغيير الخلفية", 16f, ACC_L, true), lp(b = 8))
        val tabs = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun tab(t: String, on: Boolean, f: () -> Unit) = label(t, 13f, if (on) Color.BLACK else 0xFFBBBBBB.toInt(), on).apply {
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); if (on) setColor(ACC) else setStroke(dp(1), 0xFF444444.toInt()) }
            setPadding(dp(14), dp(5), dp(14), dp(5)); setOnClickListener { f() }
        }
        tabs.addView(tab("من ملفات الفولدر", true) { }, lp(w = -2, h = -2, l = 8))
        tabs.addView(tab("من الموبايل", false) { Session.suppress = true; pickPhone.launch("image/*") }, lp(w = -2, h = -2))
        b.addView(tabs, lp(b = 10))
        root.addView(b)
        items = Vault.items(dir)
        rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@FolderSettingsActivity, 4)
            adapter = Ad()
            setPadding(dp(12), 0, dp(12), 0); layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))
        val foot = vbox().apply { setPadding(dp(16), dp(8), dp(16), dp(14)) }
        foot.addView(button("حفظ كخلفية") { saveCover() }, lp(b = 8))
        foot.addView(button("إزالة الخلفية (الصورة الأولى تلقائي)", filled = false) { removeCover() }, lp(b = 8))
        foot.addView(button("قفل الفولدر", filled = false) { startActivity(Intent(this, LockSetupActivity::class.java).putExtra("name", dir.name)) }, lp(b = 6))
        foot.addView(label("الصورة الأصلية ما بتتغيرش، الخلفية مجرد معاينة مصغرة", 11f, 0xFF777777.toInt()).apply { gravity = Gravity.CENTER })
        root.addView(foot)
        setContentView(root)
        showCurrent()
    }

    private fun showCurrent() {
        val c = Vault.coverFile(dir)
        val src: File? = if (meta.cover && c.exists()) c else items.firstOrNull()
        if (src != null) Thumbs.load(src, 500) { b -> if (b != null && !fromPhone && selected == null) preview.setImageBitmap(b) }
    }

    private fun loadPhone(uri: Uri) {
        Thread {
            val bmp = try {
                val tmp = File(cacheDir, "cover_pick"); contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                Thumbs.decode(tmp, 700)
            } catch (e: Exception) { null }
            runOnUiThread {
                if (bmp == null) { Toast.makeText(this, "تعذر فتح الصورة", Toast.LENGTH_LONG).show(); return@runOnUiThread }
                phoneBmp = bmp; fromPhone = true; selected = null
                preview.setImageBitmap(bmp); rv.adapter?.notifyDataSetChanged()
            }
        }.start()
    }

    private fun saveCover() {
        val sel = selected; val pb = phoneBmp
        if (sel == null && pb == null) { Toast.makeText(this, "اختار صورة الأول", Toast.LENGTH_SHORT).show(); return }
        Thread {
            val bmp = if (fromPhone) pb else sel?.let { Thumbs.make(it, 700) }
            var ok = false
            if (bmp != null) try { Vault.coverFile(dir).writeBytes(Thumbs.jpeg(bmp)); meta.cover = true; Vault.writeMeta(dir, meta); ok = true } catch (e: Exception) { }
            runOnUiThread {
                Toast.makeText(this, if (ok) "تم تعيين الخلفية" else "تعذر تعيين الخلفية", Toast.LENGTH_SHORT).show()
                if (ok) finish()
            }
        }.start()
    }

    private fun removeCover() {
        Vault.coverFile(dir).delete(); meta.cover = false; Vault.writeMeta(dir, meta)
        selected = null; phoneBmp = null; fromPhone = false
        Toast.makeText(this, "تمت إزالة الخلفية", Toast.LENGTH_SHORT).show()
        finish()
    }

    inner class VH(val cell: FrameLayout, val iv: ImageView, val tick: TextView) : RecyclerView.ViewHolder(cell)
    inner class Ad : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val cell = FrameLayout(this@FolderSettingsActivity).apply { setPadding(dp(3), dp(3), dp(3), dp(3)) }
            val iv = ImageView(this@FolderSettingsActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF161616.toInt()) }
            cell.addView(iv, FrameLayout.LayoutParams(-1, -1))
            val tick = label("✓", 12f, Color.BLACK).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACC) } }
            cell.addView(tick, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.TOP or Gravity.END).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            return VH(cell, iv, tick)
        }
        override fun onBindViewHolder(h: VH, pos: Int) {
            val f = items[pos]
            val s = (rv.width - rv.paddingLeft - rv.paddingRight) / 4
            h.cell.layoutParams = RecyclerView.LayoutParams(s, s)
            h.iv.setImageDrawable(null); h.iv.tag = f.path
            Thumbs.load(f, 300) { b -> if (h.iv.tag == f.path && b != null) h.iv.setImageBitmap(b) }
            h.tick.visibility = if (selected?.path == f.path) View.VISIBLE else View.GONE
            h.cell.setOnClickListener {
                selected = f; fromPhone = false
                Thumbs.load(f, 500) { b -> if (b != null) preview.setImageBitmap(b) }
                notifyDataSetChanged()
            }
        }
    }
}
