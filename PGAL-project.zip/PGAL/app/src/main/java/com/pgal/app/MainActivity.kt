package com.pgal.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

class MainActivity : BaseActivity() {
    private lateinit var content: FrameLayout
    private var filter = ""
    private var pendingFolder: String? = null
    private val hues = intArrayOf(20, 200, 120, 300, 60, 250, 10, 170)

    private val unlockFolder = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val n = pendingFolder; pendingFolder = null
        if (r.resultCode == RESULT_OK && n != null) openFolder(n)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        setContentView(content)
    }

    override fun onResume() {
        super.onResume()
        if (!Session.unlocked) return
        if (!Vault.hasAccess()) { showPermission(); return }
        if (!Vault.init()) { showMessage("تعذر إنشاء المجلد الخاص. تأكد من إذن الوصول لكل الملفات."); return }
        render()
    }

    private fun showMessage(m: String) {
        content.removeAllViews()
        content.addView(label(m, 16f, ACC_L).apply { gravity = Gravity.CENTER; setPadding(dp(30), dp(30), dp(30), dp(30)) }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showPermission() {
        content.removeAllViews()
        val b = vbox().apply { gravity = Gravity.CENTER; setPadding(dp(30), dp(30), dp(30), dp(30)) }
        b.addView(logo(), lp(w = -2, h = -2, b = 26))
        b.addView(label("محتاج إذن الوصول لكل الملفات", 19f, ACC_L, true).apply { gravity = Gravity.CENTER }, lp(b = 12))
        b.addView(label("التطبيق بيحفظ صورك وفيديوهاتك في فولدر مخفي على الموبايل (اسمه بيبدأ بنقطة)، عشان تفضل موجودة حتى لو التطبيق اتمسح. أندرويد بيطلب الإذن ده من صفحة إعدادات: شغّل الخيار بتاع التطبيق وارجع.", 14f, 0xFFAAAAAA.toInt()).apply { gravity = Gravity.CENTER }, lp(b = 22))
        b.addView(button("فتح الإعدادات") { requestAccess() }, lp())
        content.addView(b, FrameLayout.LayoutParams(-1, -1))
    }

    private fun requestAccess() {
        Session.suppress = true
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 7)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        onResume()
    }

    private fun render() {
        content.removeAllViews()
        val col = vbox()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(14), dp(14), dp(6)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val titles = vbox()
        titles.addView(label("PRIVATE", 12f, 0xFF777777.toInt()).apply { letterSpacing = 0.25f; layoutDirection = View.LAYOUT_DIRECTION_LTR })
        titles.addView(label("المعرض", 27f, ACC_L, true))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(circleBtn("🔍") { searchDialog() })
        head.addView(circleBtn("⋮") { showMenu(it) })
        col.addView(head)
        val list = Vault.folders().filter { filter.isEmpty() || it.name.contains(filter, true) }
        val sv = ScrollView(this)
        if (list.isEmpty()) {
            sv.addView(label(if (filter.isEmpty()) "مفيش فولدرات لسه. دوس + عشان تبدأ." else "مفيش نتيجة.", 15f, GREY).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(-1, dp(300)))
        } else {
            val row = LinearLayout(this).apply { setPadding(dp(16), dp(12), dp(16), dp(110)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
            val c1 = vbox(); val c2 = vbox().apply { setPadding(0, dp(34), 0, 0) }
            row.addView(c1, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, dp(6), 0) })
            row.addView(c2, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, dp(6), 0) })
            list.forEachIndexed { i, f ->
                val tall = ((i / 2) + (i % 2)) % 2 == 0
                (if (i % 2 == 0) c1 else c2).addView(folderCard(f, i, tall), lp(b = 12))
            }
            sv.addView(row)
        }
        col.addView(sv, LinearLayout.LayoutParams(-1, -1))
        content.addView(col)
        val fab = TextView(this).apply {
            text = "+"; textSize = 32f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACC) }
            elevation = dp(6).toFloat()
            setOnClickListener { fabMenu() }
        }
        content.addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(24), 0, dp(24), dp(28)) })
    }

    private fun folderCard(f: Folder, i: Int, tall: Boolean): View {
        val h = hues[i % hues.size]
        val card = FrameLayout(this).apply {
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(20).toFloat()) }
            }
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.HSVToColor(floatArrayOf(h.toFloat(), 0.3f, 0.34f)), Color.HSVToColor(floatArrayOf(((h + 50) % 360).toFloat(), 0.35f, 0.14f))))
        }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        card.addView(iv, FrameLayout.LayoutParams(-1, -1))
        card.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xDD000000.toInt(), 0x00000000)) }, FrameLayout.LayoutParams(-1, -1))
        val hidden = f.locked && f.name !in Session.openFolders
        if (f.locked) {
            card.addView(label("🔒", 13f, Color.WHITE).apply {
                background = GradientDrawable().apply { setColor(0x99141414.toInt()); cornerRadius = dp(12).toFloat() }
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(10), dp(10), dp(10), dp(10)) })
        }
        val txt = vbox().apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
        txt.addView(label(f.name, 17f, Color.WHITE, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        val cnt = if (f.videos > 0 && f.count == f.videos) "${f.count} فيديو" else "${f.count} عنصر"
        txt.addView(label(cnt, 11f, ACC_L))
        card.addView(txt, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        card.layoutParams = LinearLayout.LayoutParams(-1, dp(if (tall) 210 else 150))
        // cover: chosen image, else the first item
        val cover = Vault.coverFile(f.dir)
        val src: File? = if (f.meta.cover && cover.exists()) cover else Vault.items(f.dir).firstOrNull()
        if (src != null) Thumbs.load(src, 400) { b ->
            if (b != null) iv.setImageBitmap(if (hidden) Thumbs.blurred(b) else b)
        }
        card.setOnClickListener { openFolder(f.name, f) }
        return card
    }

    private fun openFolder(name: String, folder: Folder? = null) {
        val f = folder ?: Vault.folders().firstOrNull { it.name == name } ?: return
        if (f.locked && name !in Session.openFolders) {
            pendingFolder = name
            unlockFolder.launch(Intent(this, FolderUnlockActivity::class.java).putExtra("name", name))
            return
        }
        startActivity(Intent(this, FolderActivity::class.java).putExtra("name", name))
    }

    private fun searchDialog() {
        val e = field("اسم الفولدر").apply { setText(filter) }
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0); addView(e) }
        dlg(this).setTitle("بحث").setView(box)
            .setPositiveButton("بحث") { _, _ -> filter = e.text.toString().trim(); render() }
            .setNeutralButton("مسح") { _, _ -> filter = ""; render() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun fabMenu() {
        dlg(this).setItems(arrayOf("فولدر جديد", "إضافة صور وفيديوهات")) { _, w ->
            if (w == 0) newFolderDialog() else startActivity(Intent(this, ImportActivity::class.java))
        }.show()
    }

    private fun newFolderDialog() {
        val e = field("اسم الفولدر")
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0); addView(e) }
        dlg(this).setTitle("فولدر جديد").setView(box)
            .setPositiveButton("إنشاء") { _, _ ->
                val f = Vault.createFolder(e.text.toString())
                if (f == null) Toast.makeText(this, "الاسم فاضي أو موجود قبل كده", Toast.LENGTH_LONG).show() else render()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "الأمان والخصوصية")
        m.menu.add(0, 2, 1, "قفل التطبيق الآن")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> startActivity(Intent(this, SecurityActivity::class.java))
                2 -> { Session.lock(); onStart() }
            }
            true
        }
        m.show()
    }
}
