package com.pgal.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class FolderActivity : BaseActivity() {
    private lateinit var dir: File
    private var all: List<File> = emptyList()
    private var shown: List<File> = emptyList()
    private var mode = 0 // 0 all, 1 photos, 2 videos
    private val sel = LinkedHashSet<String>()
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var rv: RecyclerView
    private lateinit var bottom: LinearLayout
    private lateinit var chips: LinearLayout
    private lateinit var backBtn: TextView
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val name = intent.getStringExtra("name") ?: ""
        dir = File(Vault.root(), name)
        val m = Vault.readMeta(dir)
        if (!dir.isDirectory || (m.lock != "none" && name !in Session.openFolders)) { finish(); return }
        val root = vbox().apply { setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(10), dp(12), dp(4)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        backBtn = label("→", 24f, ACC).apply { setPadding(dp(14), dp(6), dp(14), dp(6)); setOnClickListener { onBack() } }
        bar.addView(backBtn)
        val tb = vbox()
        title = label(name, 24f, ACC_L, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        sub = label("", 12f, 0xFF777777.toInt())
        tb.addView(title); tb.addView(sub)
        bar.addView(tb, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(circleBtn("⋮") { showMenu(it) })
        root.addView(bar)
        chips = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), dp(8)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(chips)
        rv = RecyclerView(this).apply {
            val gm = GridLayoutManager(this@FolderActivity, 3)
            gm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(p: Int) = if (p == 0 && featured()) 3 else 1
            }
            layoutManager = gm
            adapter = this@FolderActivity.adapter
            setPadding(dp(12), dp(4), dp(12), dp(90)); clipToPadding = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))
        bottom = LinearLayout(this).apply {
            setBackgroundColor(0xFF111111.toInt()); setPadding(dp(8), dp(10), dp(8), dp(18)); visibility = View.GONE
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun act(t: String, f: () -> Unit) = label(t, 14f, ACC).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)); setOnClickListener { f() } }
        bottom.addView(act("↪ نقل") { Actions.move(this, selFiles()) { clearSel(); reload() } }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(act("⤓ إخراج") { Actions.export(this, selFiles()) { clearSel(); reload() } }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(act("🗑 حذف") { Actions.delete(this, selFiles()) { clearSel(); reload() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bottom)
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() { onBack() } })
    }

    override fun onResume() {
        super.onResume()
        if (Session.unlocked && ::dir.isInitialized) reload()
    }

    override fun onDestroy() { durPool.shutdown(); super.onDestroy() }

    private fun onBack() { if (sel.isNotEmpty()) { clearSel(); adapter.notifyDataSetChanged() } else finish() }
    private fun featured() = mode == 0 && sel.isEmpty() && shown.size >= 4
    private fun selFiles() = shown.filter { it.path in sel }
    private fun clearSel() { sel.clear(); updateBars() }

    private fun reload() {
        all = Vault.items(dir)
        applyFilter()
    }

    private fun applyFilter() {
        shown = when (mode) { 1 -> all.filter { Vault.isImage(it) }; 2 -> all.filter { Vault.isVideo(it) }; else -> all }
        sel.retainAll(shown.map { it.path }.toSet())
        buildChips(); updateBars(); adapter.notifyDataSetChanged()
    }

    private fun buildChips() {
        chips.removeAllViews()
        val names = arrayOf("الكل", "صور", "فيديو")
        for (i in 0..2) {
            val on = i == mode
            chips.addView(label(names[i], 13f, if (on) Color.BLACK else 0xFFBBBBBB.toInt(), on).apply {
                background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); if (on) setColor(ACC) else { setColor(0xFF161616.toInt()); setStroke(dp(1), 0xFF333333.toInt()) } }
                setPadding(dp(14), dp(5), dp(14), dp(5))
                setOnClickListener { mode = i; applyFilter() }
            }, lp(w = -2, h = -2, l = 8))
        }
    }

    private fun updateBars() {
        val photos = all.count { Vault.isImage(it) }; val vids = all.count { Vault.isVideo(it) }
        if (sel.isEmpty()) { title.text = dir.name; sub.text = "$photos صورة · $vids فيديو" }
        else { title.text = "${sel.size} مختارين"; sub.text = "" }
        bottom.visibility = if (sel.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "إضافة صور وفيديوهات")
        m.menu.add(0, 2, 1, "إعدادات الفولدر")
        m.menu.add(0, 3, 2, "تحديد الكل")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> startActivity(Intent(this, ImportActivity::class.java).putExtra("name", dir.name))
                2 -> startActivity(Intent(this, FolderSettingsActivity::class.java).putExtra("name", dir.name))
                3 -> { sel.clear(); shown.forEach { f -> sel.add(f.path) }; updateBars(); adapter.notifyDataSetChanged() }
            }
            true
        }
        m.show()
    }

    private fun tap(f: File, pos: Int) {
        if (sel.isNotEmpty()) { toggle(f); return }
        startActivity(Intent(this, ViewerActivity::class.java).putExtra("path", f.path).putExtra("mode", mode))
    }

    private fun toggle(f: File) {
        if (!sel.add(f.path)) sel.remove(f.path)
        updateBars(); adapter.notifyDataSetChanged()
    }

    inner class VH(val cell: FrameLayout, val iv: ImageView, val badge: TextView, val tick: TextView) : RecyclerView.ViewHolder(cell)

    inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = shown.size
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val cell = FrameLayout(this@FolderActivity).apply { setPadding(dp(2), dp(2), dp(2), dp(2)) }
            val inner = FrameLayout(this@FolderActivity).apply {
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
                }
                setBackgroundColor(0xFF161616.toInt())
            }
            val iv = ImageView(this@FolderActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            inner.addView(iv, FrameLayout.LayoutParams(-1, -1))
            val badge = label("", 10f, Color.WHITE).apply {
                background = GradientDrawable().apply { setColor(0xAA000000.toInt()); cornerRadius = dp(10).toFloat() }
                setPadding(dp(7), dp(2), dp(7), dp(2)); layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            inner.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
            val tick = label("✓", 13f, Color.BLACK).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACC) }
            }
            inner.addView(tick, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.END).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
            cell.addView(inner, FrameLayout.LayoutParams(-1, -1))
            return VH(cell, iv, badge, tick)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val f = shown[pos]
            val w = (rv.width - rv.paddingLeft - rv.paddingRight) / 3
            val big = pos == 0 && featured()
            h.cell.layoutParams = RecyclerView.LayoutParams(if (big) w * 3 else w, if (big) (w * 1.9f).toInt() else w)
            h.iv.setImageDrawable(null)
            h.iv.tag = f.path
            val sz = if (big) 700 else 300
            val c = Thumbs.peek(f, sz)
            if (c != null) h.iv.setImageBitmap(c) else Thumbs.load(f, sz) { b -> if (h.iv.tag == f.path && b != null) h.iv.setImageBitmap(b) }
            if (Vault.isVideo(f)) {
                h.badge.visibility = View.VISIBLE
                val cd = durCache[f.path]
                h.badge.text = "▶ " + (cd ?: "")
                if (cd == null) durPool.execute {
                    val d = dur(f)
                    runOnUiThread { if (h.iv.tag == f.path) h.badge.text = "▶ $d" }
                }
            } else h.badge.visibility = View.GONE
            val on = f.path in sel
            h.tick.visibility = if (on) View.VISIBLE else View.GONE
            h.iv.alpha = if (on) 0.6f else 1f
            h.cell.setOnClickListener { tap(f, pos) }
            h.cell.setOnLongClickListener { toggle(f); true }
        }
    }

    private val durPool = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val durCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private fun dur(f: File): String = durCache.getOrPut(f.path) {
        val r = android.media.MediaMetadataRetriever()
        try {
            r.setDataSource(f.path)
            val d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            "${d / 60000}:${"%02d".format(d / 1000 % 60)}"
        } catch (e: Exception) { "" } finally { try { r.release() } catch (e: Exception) { } }
    }
}
