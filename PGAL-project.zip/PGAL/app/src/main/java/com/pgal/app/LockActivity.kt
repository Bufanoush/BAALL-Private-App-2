package com.pgal.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback

class LockActivity : BaseActivity() {
    override val needsUnlock = false
    private lateinit var pw: EditText
    private lateinit var pw2: EditText
    private lateinit var msg: TextView
    private var setup = false
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup = !Prefs.hasPassword
        val root = vbox().apply { setBackgroundColor(Color.BLACK); setPadding(dp(28), dp(60), dp(28), dp(20)); gravity = Gravity.TOP }
        root.addView(logo(), lp(w = -2, h = -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(label(if (setup) "اختار كلمة السر" else "اكتب كلمة السر", 18f, ACC_L).apply { gravity = Gravity.CENTER }, lp(t = 30, b = 18))
        pw = pass("كلمة السر")
        root.addView(pw, lp(b = 10))
        pw2 = pass("أكد كلمة السر")
        msg = label("", 14f, 0xFFE57373.toInt()).apply { gravity = Gravity.CENTER }
        val go = button(if (setup) "حفظ وفتح" else "فتح") { submit() }
        if (setup) {
            root.addView(pw2, lp(b = 10))
            root.addView(label("مسموح بحروف وأرقام ومسافات ورموز.", 13f, 0xFF999999.toInt()), lp(b = 10))
            pw.imeOptions = EditorInfo.IME_ACTION_NEXT
            pw2.imeOptions = EditorInfo.IME_ACTION_DONE
            pw2.setOnEditorActionListener { _, _, _ -> submit(); true }
        } else {
            pw.imeOptions = EditorInfo.IME_ACTION_DONE
            pw.setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        root.addView(msg, lp(b = 6))
        root.addView(go, lp())
        if (!setup) {
            if (Prefs.fingerprint) {
                val fp = label("☝", 38f, ACC).apply {
                    gravity = Gravity.CENTER
                    background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(1), ACC) }
                    setOnClickListener { tryFingerprint() }
                }
                root.addView(fp, LinearLayout.LayoutParams(dp(76), dp(76)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(26) })
                root.addView(label("أو افتح بالبصمة", 13f, 0xFF999999.toInt()).apply { gravity = Gravity.CENTER }, lp(t = 6))
            }
            if (Prefs.question.isNotEmpty()) {
                root.addView(label("نسيت كلمة السر؟ (سؤال الأمان)", 13f, ACC).apply {
                    gravity = Gravity.CENTER; paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
                    setOnClickListener { forgot() }
                }, lp(t = 22))
            }
        }
        setContentView(root)
        pw.requestFocus()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finishAffinity() }
        })
    }

    override fun onResume() {
        super.onResume()
        if (!setup && Prefs.fingerprint && !fpShown) { fpShown = true; tryFingerprint() }
    }
    private var fpShown = false

    private fun tryFingerprint() { askFingerprint("افتح بالبصمة") { Session.unlocked = true; finish() } }

    private fun submit() {
        if (busy) return
        val p = pw.text.toString()
        if (setup) {
            if (p.length < 4) { msg.text = "كلمة السر لازم تكون 4 حروف على الأقل"; return }
            if (p != pw2.text.toString()) { msg.text = "كلمتين السر مش متطابقتين"; return }
            Prefs.setPassword(p); Session.unlocked = true; finish(); return
        }
        if (p.isEmpty()) return
        busy = true; msg.text = ""
        Thread {
            val ok = Prefs.checkPassword(p)
            runOnUiThread {
                busy = false
                if (ok) { Session.unlocked = true; finish() } else { msg.text = "كلمة السر غلط"; pw.setText("") }
            }
        }.start()
    }

    private fun forgot() {
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0) }
        box.addView(label(Prefs.question, 17f, ACC_L), lp(b = 12))
        val a = field("الإجابة")
        box.addView(a)
        val d = dlg(this).setTitle("سؤال الأمان").setView(box)
            .setPositiveButton("تأكيد", null).setNegativeButton("إلغاء", null).create()
        d.setOnShowListener {
            d.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (Prefs.checkAnswer(a.text.toString())) { d.dismiss(); newPassword() } else { a.setText(""); a.hint = "الإجابة غلط، جرب تاني" }
            }
        }
        d.show()
    }

    /** The secret question only resets the password; it does not open the app by itself. */
    private fun newPassword() {
        val box = vbox().apply { setPadding(dp(20), dp(10), dp(20), 0) }
        val n1 = pass("كلمة السر الجديدة"); val n2 = pass("أكد كلمة السر الجديدة")
        box.addView(n1, lp(b = 8)); box.addView(n2)
        val d = dlg(this).setTitle("كلمة سر جديدة").setView(box)
            .setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        d.setOnShowListener {
            d.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = n1.text.toString()
                if (a.length < 4) { Toast.makeText(this, "أقل من 4 حروف", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                if (a != n2.text.toString()) { Toast.makeText(this, "الكلمتين مش متطابقتين", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                Prefs.setPassword(a); d.dismiss()
                Toast.makeText(this, "تم. اكتب كلمة السر الجديدة لفتح التطبيق", Toast.LENGTH_LONG).show()
            }
        }
        d.show()
    }
}
